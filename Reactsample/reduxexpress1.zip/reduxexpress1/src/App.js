import "./App.css";
import RE_AddDoctor from './component/RE_AddDoctor'

function App() {

  return (
    <div className="App">
      <header className="App-header">

        <RE_AddDoctor/>

      </header>
    </div>
  );
}

export default App;


